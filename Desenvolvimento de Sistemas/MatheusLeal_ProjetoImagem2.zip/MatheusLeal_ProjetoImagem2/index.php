<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Início do Projeto</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: lightcyan;
            }
            .menu {
                background-color: #003366;
                overflow: hidden;
            }
            .menu a .dropbtn{
                float: left;
                font-size: 16px;
                color: white;
                text-align: center;
                padding: 14px 20px;
                text-decoration: none;
            }
            .dropdown {
                float: left;
                overflow: hidden;
            }
            .dropdown .dropbtn {
                font-size: 16px;    
                border: none;
                outline: none;
                color: white;
                padding: 14px 20px;
                background-color: inherit;
                font-family: inherit;
                margin: 0;
            }
            .menu a:hover, .dropdown:hover .dropbtn {
                background-color: #336699;
            }
            .dropdown-content {
                display: none;
                position: absolute;
                background-color: #336699;
                min-width: 200px;
                z-index: 1;
            }
            .dropdown-content a {
                float: none;
                color: white;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                text-align: left;
            }
            .dropdown-content a:hover {
                background-color: #6699cc;
            }
            .dropdown:hover .dropdown-content {
                display: block;
            }
            .content {
                padding: 20px;
            }
        </style>
    </head>
    <body>
        <div class="content">
            <h1>Bem-vindo ao Sistema de Funcionários</h1>
            <p>Utilize o menu abaixo para navegar entre as funcionalidades.</p>
        </div>

        <div class="menu">
            <div class="dropdown">
                <button class="dropbtn">Funcionário 
                    ▼
                </button>
                <div class="dropdown-content">
                    <a href="cadastro_funcionario.php">Cadastrar Funcionário</a>
                    <a href="consulta_funcionario.php">Consultar Funcionário</a>
                    <a href="visualiza_funcionario.php">Visualizar Funcionário</a>
                </div>
            </div>
        </div>
    </body>
</html>
