<?php
//CONEXÃO COM O BANCO DE DADOS
$host = 'localhost:3306';
$dbname = 'bd_imagem';
$username = 'root';
$password = '';

try{
    //CRIA UMA NOVA INSTANCIA DE PDO PARA CONECTAR AO BANCO DE DADOS
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //DEFINE O MODO DE ERRO DO PDO PARA EXCEÇÕES
    
    //RECUPERA TODOS OS FUNCIONARIOS DO BANCO DE DADOS
    $sql = "SELECT id, nome FROM funcionarios";
    $stmt = $pdo->prepare($sql);//PREPARA A INSTRUÇÃO SQL PARA EXECUÇÃO
    $stmt->execute();//EXECUTA A INSTRUÇÃO
    $funcionarios = $stmt->fetchAll(PDO::FETCH_ASSOC);//BUSCA TODOS OS RESULTADOS COM UMA MATRIZ ASSOCIATIVA

    //VERIFICA SE FOI SOLICITADO A EXCLUSÃO DE UM FORMULARIO
    if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['excluir_id'])){
        $excluir_id = $_POST['excluir_id'];
        $sql_excluir = "DELETE FROM funcionarios WHERE id = :id";
        $stmt_excluir = $pdo->prepare($sql_excluir);
        $stmt_excluir->bindParam(':id', $excluir_id, PDO::PARAM_INT);
        $stmt_excluir->execute();

        //REDIRECIONA PARA EVITAR O REENVIO DO FORMULARIO
        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
    }
}catch (PDOException $e){
    echo "Erro.".$e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Consulta Funcionario</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                background:lightcyan;
            }

            h1{
                text-align: center;
                color: #0056b3
            }
            ul{
                text-align: center;
            }

            .menu { 
                background-color: #003366; 
                overflow: hidden; 
            }

            .menu a, .dropbtn {
                float: left;
                font-size: 16px;
                color: white;
                padding: 14px 20px;
                text-decoration: none;
                background: none;
                border: none;
                cursor: pointer;
            }
            .menu a:hover, .dropdown:hover .dropbtn { background-color: #336699; }
            .dropdown { float: left; overflow: hidden; }
            .dropdown-content {
                display: none;
                position: absolute;
                background-color: #336699;
                min-width: 200px;
                z-index: 1;
            }
            .dropdown-content a {
                color: white;
                padding: 12px 16px;
                display: block;
                text-align: left;
            }
            .dropdown-content a:hover { background-color: #6699cc; }
            .dropdown:hover .dropdown-content { display: block; }
            .content { padding: 20px; }
        </style>
    </head>
    <body>
        <div class="menu">
            <a href="index.php">Início</a>
            <a href="cadastro_funcionario.php">Cadastrar Funcionário</a>
            <a href="consulta_funcionario.php">Consultar Funcionário</a>
            <a href="visualiza_funcionario.php">Visualizar Funcionário</a>
        </div>
        <br>
        <h1>Funcionarios</h1>

        <ul>
            <?php foreach($funcionarios as $funcionario):?>
            <a href="visualizar_funcionario.php?id=<?= $funcionario['id'] ?>">
                <?= htmlspecialchars($funcionario['nome']) ?>
            </a>
            <form method="post" style="display:inline;">
                <input type="hidden" name="excluir_id" value="<?= $funcionario['id'] ?>">
                <button type="submit"></button>
            </form>
            <?php endforeach; ?>
        </ul>
    </body>
</html>