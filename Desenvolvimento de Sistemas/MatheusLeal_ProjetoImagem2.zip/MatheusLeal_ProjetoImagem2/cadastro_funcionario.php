<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Formulário Cadastro</title>
        <style>
            /* Reset básico */
            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }

            /* Estilo geral da página */
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background:rgb(187, 216, 216);
                color: #333;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }

            /* Container principal */
            .container {
                background: #fff;
                padding: 30px;
                border-radius: 12px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
                width: 100%;
                max-width: 500px;
            }

            /* Títulos */
            h1, h2 {
                text-align: center;
                margin-bottom: 20px;
                color: #0056b3;
            }

            /* Formulários */
            form {
                display: flex;
                flex-direction: column;
                gap: 15px;
            }

            /* Labels e inputs */
            label {
                font-weight: 600;
                margin-bottom: 5px;
                color: #333;
            }

            input[type="text"],
            input[type="tel"] {
                padding: 10px;
                font-size: 16px;
                border: 1px solid #ccc;
                border-radius: 6px;
                transition: border-color 0.3s ease;
            }

            input:focus {
                border-color: #007bff;
                outline: none;
            }

            /* Botões */
            button {
                background-color: #007bff;
                color: #fff;
                border: none;
                padding: 12px;
                border-radius: 6px;
                font-size: 16px;
                cursor: pointer;
                transition: background-color 0.3s ease;
            }

            button:hover {
                background-color: #0056b3;
            }

            /* Tabela */
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }

            table th,
            table td {
                border: 1px solid #ccc;
                padding: 10px;
                text-align: left;
            }

            table th {
                background-color: #007bff;
                color: #fff;
            }

            table tr:nth-child(even) {
                background-color: #f2f2f2;
            }

            /* Responsividade */
            @media (max-width: 600px) {
                .container {
                    padding: 20px;
                }

                table th,
                table td {
                    font-size: 14px;
                }
            }

        </style>
    </head>
    <body>
        
        <div class="container">
            <h1>Cadastro</h1>
            <h2>Funcionario</h2>
            <!--FORMULARIO PARA CADASTRAR FUNCIONARIO-->
            <form action="salvar_funcionario.php" method="post" enctype="multipart/form-data">
                <!--CAMPO PARA INSERIR O NOME DO FUNCIONARIO-->
                <label for="nome">Nome: </label>
                <input type="text" name="nome" id="nome" required><br>

                <!--CAMPO PARA INSERIR O TELEFONE DO FUNCIONARIO-->
                <label for="telefone">Telefone: </label>
                <input type="tel" name="telefone" id="telefone" required>

                <!--CAMPO PARA FAZER UPLOAD DA FOTO DO FUNCIONARIO-->
                <label for="foto">Foto: </label>
                <input type="file" name="foto" id="foto" required><br>

                <!--BOTÃO PARA ENVIAR O FORMULARIO-->
                <button type="submit">Cadastrar</button><br>                
            </form>
            <button><a href="index.php">Início</a></button>
        </div>
    </body>
</html>