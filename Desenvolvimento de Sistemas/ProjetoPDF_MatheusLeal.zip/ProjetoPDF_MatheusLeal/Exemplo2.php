<?php
//Inicia o buffer de saida para capturar qualquer conteúdo
ob_start();

require_once 'fpdf/fpdf.php';

//Cria uma nova instancia da classe FPDF
$pdf = new FPDF("P", "pt", "A4");

class NovoPDF extends FPDF {
    function Header(){
        //INSERE IMAGEM
        $this->Image('logo.png', 5, 1, 65);

        //PULA 30 PONTOS ABAIXO DA IMAGEM
        $this->Ln(30);//"Ln" É "LINE BREAK"

        //DEFINE A FONTE
        $this->SetFont('Arial','B',15);

        //MOVE O CURSOR 80 PONTOS PRA DIREITA
        $this->Cell(80);
        $this->Cell(40, 10, iconv('UTF-8', 'ISO-8859-1//TRANSLIT', 'Matheus Leal'),1, 0, 'C');
        //PULA 20 PONTOS PRA BAIXO 
        $this->Ln(20);
    }

    function Footer(){
        //POSIÇÃO VERTICAL A 15 PONTOS DO FIM DA PÁGINA
        $this->SetY(-15);

        //FONTE 
        $this->SetFont('Arial', 'I', 8);

        //NÚMERO DA PÁGINA
        $this->Cell(0, 10, 'Pagina'.$this->PageNo().'/{nb}', 0, 0, 'C');
    }
}

//CRIA O PDF USANDO A CLASSE PERSONALIZADA
$pdf = new NovoPDF();

//ATIVA O USO DO {nb} PARA TOTAL DE PÁGINAS NO RODAPÉ
$pdf->AliasNbPages();

//ADD A 1 PÁGINA
$pdf->AddPage();

//FONTE
$pdf->SetFont('Times', "",12);

//GERA 80 LINHAS COM CONTEÚDO SIMULADO
for ($i = 1; $i <= 80; $i++){
    //Largura total, altura 10, sem borda, quebra de linha
    $pdf->Cell(0, 10, 'Teste de Linha'.$i, 0, 1);
}

$pdf->Output("relatorio_produtos_MatheusLeal.pdf", "I");
?>